<template>
  Pas trouvée la maquete
  </template>
  
  <script>
  import '@/assets/css/global.css'; // Importation du fichier CSS global
  
  export default {
    name: 'BonsDeTravail',
  };
  </script>
  
  <style scoped>
  .text-primary {
    color: #05004E;
  }
  
  .text-dark {
    color: #3C3C3C;
  }
  
  .v-card {
    background-color: #FFFFFF;
  }
  
  .v-btn {
    background-color: #F1F5FF;
    border-radius: 50%;
  }
  
  h1 {
    color: #05004E;
  }
  </style>
  